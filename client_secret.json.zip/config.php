<?php
require_once 'vendor/autoload.php';

// Initialize the Google API client
$google_client = new Google_Client();
$google_client->setClientId('429506179183-u6irvvf56hacret5h4ougecjjneeb0bi.apps.googleusercontent.com');
$google_client->setClientSecret('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');
$google_client->setRedirectUri('https://techixpert.com/clients/FelixViage/profile.php');

$google_client->addScope('email');
$google_client->addScope('profile');

$google_service = new Google_Service_Oauth2($google_client);
?>
